/**
 * Velure Core — Canvas Bridge v3.2.1
 * Injected ONLY inside the canvas iframe (&mode=canvas).
 *
 * Responsibilities:
 *  1. Attribute data-vc-widget to all editable elements
 *  2. Hover → light blue outline
 *  3. Click → dashed blue halo + postMessage to parent
 *  4. Double-click on text → contenteditable + green outline
 *  5. Receive postMessage from parent (apply styles, deselect, select)
 *
 * @package VelureCore
 * @since 3.2.1
 */

(function () {
        'use strict';

        /* ── Detect section from body attribute (set by canvas-renderer.php) ── */
        var section = document.body.getAttribute('data-vc-section') || '';
        if (!section) return;

        var selectedEl = null;
        var editingEl  = null;

        /* ═══════════════════════════════════════════════════════════════════
           WIDGET SELECTOR MAP
       One entry per editable element type, keyed by section slug.
       Multiple items with the same selector use { multiple: true } to
       auto-append an index suffix  (e.g.  feature-item-0, feature-item-1).
           ═══════════════════════════════════════════════════════════════════ */
        var WIDGET_MAP = {
                hero: [
                        { widget: 'hero-bg',       selector: '.v-hero-slide-bg',                  label: 'Image de fond',           editable: false },
                        { widget: 'hero-overlay',   selector: '.v-hero-slide-overlay',              label: 'Overlay',                  editable: false },
                        { widget: 'hero-eyebrow',   selector: '.v-hero-slide-content > .velure-eyebrow', label: 'Sur-titre',           editable: true  },
                        { widget: 'hero-title',     selector: '.v-hero-slide-content > h2',        label: 'Titre principal',         editable: true  },
                        { widget: 'hero-subtitle',  selector: '.v-hero-subtitle',                   label: 'Sous-titre',              editable: true  },
                        { widget: 'hero-cta',       selector: '.v-hero-slide-content > .velure-btn', label: 'Bouton CTA',            editable: false },
                        { widget: 'hero-side',      selector: '.v-hero-side',                       label: 'Blocs lateraux',          editable: false },
                        { widget: 'hero-dots',      selector: '.v-hero-dots',                       label: 'Navigation slides',       editable: false },
                ],
                features: [
                        { widget: 'feature-item',   selector: '.velure-feature-item',               label: 'Element de confiance',    multiple: true, editable: false },
                ],
                categories: [
                        { widget: 'cat-heading',    selector: '.velure-section-heading',            label: 'En-tete section',         editable: false },
                        { widget: 'cat-card',       selector: '.velure-category-card',              label: 'Carte categorie',         multiple: true, editable: false },
                        { widget: 'cat-cta',        selector: '.velure-btn-outline',                label: 'Bouton CTA',              editable: false },
                ],
                products: [
                        { widget: 'prod-heading',   selector: '.velure-section-heading',            label: 'En-tete section',         editable: false },
                        { widget: 'prod-card',      selector: '.velure-product-card',               label: 'Carte produit',           multiple: true, editable: false },
                        { widget: 'prod-cta',       selector: '.velure-btn-outline',                label: 'Bouton CTA',              editable: false },
                ],
                split_banner: [
                        { widget: 'banner-left',    selector: '.velure-split-side:first-child',     label: 'Banniere gauche',         editable: false },
                        { widget: 'banner-right',   selector: '.velure-split-side:last-child',      label: 'Banniere droite',         editable: false },
                ],
                marquee: [
                        { widget: 'marquee-track',  selector: '.velure-marquee',                    label: 'Bandeau defilant',        editable: false },
                ],
                testimonials: [
                        { widget: 'testi-heading',  selector: '.velure-section-heading',            label: 'En-tete section',         editable: false },
                        { widget: 'testi-card',     selector: '.velure-testimonial-card',           label: 'Carte temoignage',        multiple: true, editable: false },
                ],
                blog: [
                        { widget: 'blog-heading',   selector: '.velure-section-heading',            label: 'En-tete section',         editable: false },
                        { widget: 'blog-card',      selector: '.velure-blog-card',                  label: 'Carte article',           multiple: true, editable: false },
                        { widget: 'blog-cta',       selector: '.velure-btn-outline',                label: 'Bouton CTA',              editable: false },
                ],
                instagram: [
                        { widget: 'ig-heading',     selector: '.velure-section-heading',            label: 'En-tete section',         editable: false },
                        { widget: 'ig-item',        selector: '.velure-instagram-item',             label: 'Image Instagram',         multiple: true, editable: false },
                ],
        };

        /* ═══════════════════════════════════════════════════════════════════
           CONTENT KEY MAP
           Maps editable widget base IDs to their settings key.
           Sent to the parent so auto-save knows which option to update.
           ═══════════════════════════════════════════════════════════════════ */
        var CONTENT_KEY_MAP = {
                'hero-eyebrow':  'hero_slides.0.eyebrow',
                'hero-title':    'hero_slides.0.title',
                'hero-subtitle': 'hero_slides.0.subtitle',
                'hero-cta':      'hero_slides.0.cta_text',
        };

        var widgets = WIDGET_MAP[section] || [];

        /* ═══════════════════════════════════════════════════════════════════
           1. INJECT data-vc-widget ATTRIBUTES
           ═══════════════════════════════════════════════════════════════════ */
        function initWidgets() {
                widgets.forEach(function (def) {
                        var els = document.querySelectorAll(def.selector);
                        els.forEach(function (el, index) {
                                var widgetId = def.widget;
                                if (def.multiple) {
                                        widgetId = def.widget + '-' + index;
                                }
                                el.setAttribute('data-vc-widget', widgetId);
                                el.setAttribute('data-vc-label', def.label);
                                el.setAttribute('data-vc-editable', def.editable ? 'true' : 'false');
                                el.setAttribute('data-vc-base', def.widget);
                                if (def.multiple) {
                                        el.setAttribute('data-vc-index', String(index));
                                }

                                /* ═══ Propagate data-vc-field from child text nodes ═══
                                   If the widget wrapper doesn't have data-vc-field but a direct
                                   text child does, copy it up so onClick can find it. */
                                if (!el.getAttribute('data-vc-field')) {
                                        var fieldChild = el.querySelector('[data-vc-field]');
                                        if (fieldChild) {
                                                el.setAttribute('data-vc-field', fieldChild.getAttribute('data-vc-field'));
                                        }
                                }
                        });
                });
        }

        /* ═══════════════════════════════════════════════════════════════════
           2. SELECTION MANAGEMENT
           ═══════════════════════════════════════════════════════════════════ */
        function selectElement(el) {
                /* Deselect previous */
                if (selectedEl && selectedEl !== el) {
                        selectedEl.classList.remove('vc-widget-selected');
                }
                selectedEl = el;
                el.classList.add('vc-widget-selected');

                /* Scroll into view if needed */
                var rect = el.getBoundingClientRect();
                if (rect.top < 0 || rect.bottom > window.innerHeight) {
                        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }

                /* Notify parent */
                window.parent.postMessage({
                        action:   'vc-widget-selected',
                        widget:   el.getAttribute('data-vc-widget'),
                        base:     el.getAttribute('data-vc-base') || el.getAttribute('data-vc-widget'),
                        section:  section,
                        label:    el.getAttribute('data-vc-label') || '',
                        editable: el.getAttribute('data-vc-editable') === 'true',
                        index:    el.getAttribute('data-vc-index'),
                }, '*');
        }

        function deselectAll() {
                if (selectedEl) {
                        selectedEl.classList.remove('vc-widget-selected');
                        selectedEl = null;
                }
                closeEditing();
                window.parent.postMessage({ action: 'vc-widget-deselected' }, '*');
        }

        function closeEditing() {
                if (editingEl) {
                        editingEl.contentEditable = 'false';
                        editingEl.classList.remove('vc-editing');
                        editingEl = null;
                }
        }

        /* ═══════════════════════════════════════════════════════════════════
           3. EVENT HANDLERS
           ═══════════════════════════════════════════════════════════════════ */

        /* ── Hover: light blue outline ── */
        function onHoverIn(e) {
                var el = e.target.closest('[data-vc-widget]');
                if (el && el !== selectedEl) {
                        el.classList.add('vc-widget-hover');
                }
        }

        function onHoverOut(e) {
                var el = e.target.closest('[data-vc-widget]');
                if (el) {
                        el.classList.remove('vc-widget-hover');
                }
        }

        /* ── Click: select + halo + activate field in parent panel ── */
        function onClick(e) {
                var el = e.target.closest('[data-vc-widget]');
                if (el) {
                        e.preventDefault();
                        e.stopPropagation();
                        selectElement(el);

                        /* ═══ WIX-LIKE: Send field key to parent for panel focus ═══ */
                        var fieldKey = el.getAttribute('data-vc-field');
                        if (fieldKey) {
                                window.parent.postMessage({
                                        action: 'vc-activate-control',
                                        key: fieldKey,
                                        widget: el.getAttribute('data-vc-widget'),
                                        label: el.getAttribute('data-vc-label') || ''
                                }, '*');
                        }
                } else if (!e.target.closest('.vc-editing')) {
                        deselectAll();
                }
        }

        /* ── Double-click: contenteditable for text elements ── */
        function onDblClick(e) {
                var el = e.target.closest('[data-vc-widget]');
                if (!el) return;
                if (el.getAttribute('data-vc-editable') !== 'true') return;

                e.preventDefault();
                e.stopPropagation();

                /* Close previous editing session */
                if (editingEl && editingEl !== el) {
                        notifyContentChange(editingEl);
                        closeEditing();
                }

                editingEl = el;
                el.contentEditable = 'true';
                el.classList.add('vc-editing');
                el.focus();

                /* Select all text inside */
                var range = document.createRange();
                range.selectNodeContents(el);
                var sel = window.getSelection();
                sel.removeAllRanges();
                sel.addRange(range);
        }

        /* ── Blur: save editing + notify parent ── */
        function onBlur(e) {
                if (editingEl && e.target === editingEl) {
                        notifyContentChange(editingEl);
                        closeEditing();
                }
        }

        function notifyContentChange(el) {
                var base = el.getAttribute('data-vc-base') || el.getAttribute('data-vc-widget');
                window.parent.postMessage({
                        action:     'vc-content-changed',
                        widget:     el.getAttribute('data-vc-widget'),
                        base:       base,
                        section:    section,
                        property:   'text',
                        value:      el.textContent.trim(),
                        settingKey: CONTENT_KEY_MAP[base] || null,
                }, '*');
        }

        /* ── Keyboard ── */
        function onKeyDown(e) {
                /* Escape exits editing */
                if (editingEl && e.key === 'Escape') {
                        editingEl.blur();
                }
                /* Prevent link navigation when clicking inside a widget */
                if (e.target.closest('[data-vc-widget]') && e.key === 'Enter') {
                        if (e.target.getAttribute('contenteditable') !== 'true') {
                                e.preventDefault();
                        }
                }
        }

        /* ═══════════════════════════════════════════════════════════════════
           4. RECEIVE MESSAGES FROM PARENT
           ═══════════════════════════════════════════════════════════════════ */
        function onParentMessage(e) {
                if (!e.data || typeof e.data.action !== 'string') return;

                switch (e.data.action) {

                        /* Parent asks to apply inline CSS to a widget */
                        case 'vc-apply-style':
                                applyStyleToWidget(e.data.widget, e.data.css);
                                break;

                        /* Parent asks to update text content */
                        case 'vc-apply-text':
                                applyTextToWidget(e.data.widget, e.data.text);
                                break;

                        /* Parent asks to deselect everything */
                        case 'vc-deselect':
                                deselectAll();
                                break;

                        /* Parent asks to programmatically select a widget */
                        case 'vc-select-widget':
                                var target = document.querySelector('[data-vc-widget="' + e.data.widget + '"]');
                                if (target) selectElement(target);
                                break;
                }
        }

        function applyStyleToWidget(widgetId, css) {
                if (!css || typeof css !== 'object') return;
                var el = document.querySelector('[data-vc-widget="' + widgetId + '"]');
                if (!el) return;
                Object.keys(css).forEach(function (prop) {
                        el.style[prop] = css[prop];
                });
        }

        function applyTextToWidget(widgetId, text) {
                var el = document.querySelector('[data-vc-widget="' + widgetId + '"]');
                if (!el) return;
                el.textContent = text;
        }

        /* ═══════════════════════════════════════════════════════════════════
           5. CANVAS-SPECIFIC STYLES
           ═══════════════════════════════════════════════════════════════════ */
        function injectCanvasStyles() {
                var css = document.createElement('style');
                css.id = 'vc-canvas-bridge-css';
                css.textContent = [
                        '/* ── Canvas Bridge: Widget overlay styles ── */',
                        '[data-vc-widget] {',
                        '  cursor: pointer;',
                        '  transition: outline 0.15s ease, outline-offset 0.15s ease;',
                        '  outline: 2px solid transparent;',
                        '  outline-offset: 2px;',
                        '  position: relative;',
                        '}',

                        '/* Hover: light blue outline */',
                        '[data-vc-widget].vc-widget-hover {',
                        '  outline: 2px solid rgba(59, 130, 246, 0.45);',
                        '}',

                        '/* Selected: dashed blue halo */',
                        '[data-vc-widget].vc-widget-selected {',
                        '  outline: 2px dashed #3b82f6;',
                        '  outline-offset: 4px;',
                        '}',

                        '/* Editing: solid green outline */',
                        '[data-vc-editable="true"].vc-editing {',
                        '  outline: 2px solid #22c55e !important;',
                        '  outline-offset: 4px;',
                        '  cursor: text;',
                        '  background: rgba(255, 255, 255, 0.06);',
                        '  border-radius: 2px;',
                        '  min-width: 40px;',
                        '  min-height: 1em;',
                        '}',

                        '/* Widget label tooltip on hover */',
                        '[data-vc-widget].vc-widget-hover::after,',
                        '[data-vc-widget].vc-widget-selected::after {',
                        '  content: attr(data-vc-label);',
                        '  position: absolute;',
                        '  top: -28px;',
                        '  left: 50%;',
                        '  transform: translateX(-50%);',
                        '  background: rgba(26, 26, 46, 0.92);',
                        '  color: #C8A97E;',
                        '  font-family: "Inter", sans-serif;',
                        '  font-size: 11px;',
                        '  font-weight: 600;',
                        '  padding: 3px 10px;',
                        '  border-radius: 4px;',
                        '  white-space: nowrap;',
                        '  pointer-events: none;',
                        '  z-index: 99999;',
                        '  letter-spacing: 0.3px;',
                        '  backdrop-filter: blur(6px);',
                        '}',

                        '/* Make overlays non-blocking so clicks reach widgets behind them */',
                        '.v-hero-slide-overlay, .velure-split-side-bg {',
                        '  pointer-events: none !important;',
                        '}',

                        '/* Prevent links from navigating in canvas */',
                        '[data-vc-widget] a, a[data-vc-widget] {',
                        '  pointer-events: none;',
                        '}',

                        '/* ═══ WIX-LIKE: Editable field hover indicator ═══ */',
                        '[data-vc-field] {',
                        '  position: relative;',
                        '}',
                        '[data-vc-field]:hover::before {',
                        '  content: "✏️ Edit";',
                        '  position: absolute;',
                        '  top: -22px;',
                        '  right: -4px;',
                        '  background: rgba(59, 130, 246, 0.92);',
                        '  color: #fff;',
                        '  font-size: 10px;',
                        '  font-weight: 600;',
                        '  font-family: "Inter", sans-serif;',
                        '  padding: 2px 8px;',
                        '  border-radius: 4px;',
                        '  z-index: 99998;',
                        '  pointer-events: none;',
                        '  letter-spacing: 0.3px;',
                        '  white-space: nowrap;',
                        '  opacity: 0;',
                        '  transition: opacity 0.15s ease;',
                        '}',
                        '[data-vc-widget]:hover [data-vc-field]::before,',
                        '[data-vc-field].vc-widget-hover::before,',
                        '[data-vc-field].vc-widget-selected::before {',
                        '  opacity: 1;',
                        '}',
                ].join('\n');
                document.head.appendChild(css);
        }

        /* ═══════════════════════════════════════════════════════════════════
           6. HERO SLIDER FREEZE (canvas edit mode)
           Prevents auto-advance and ensures first slide stays visible.
           ═══════════════════════════════════════════════════════════════════ */
        function freezeHeroSlider() {
                var slider = document.querySelector('.v-hero-slider');
                if (!slider) return;

                /* Force first slide active if none are */
                var slides = slider.querySelectorAll('.v-hero-slide');
                var hasActive = false;
                slides.forEach(function(s) {
                        if (s.classList.contains('v-hero-slide--active')) hasActive = true;
                });
                if (!hasActive && slides.length > 0) {
                        slides[0].classList.add('v-hero-slide--active');
                }

                /* Remove all event listeners from slider by cloning */
                var main = slider.querySelector('.v-hero-main');
                if (main) {
                        var clone = main.cloneNode(true);
                        main.parentNode.replaceChild(clone, main);
                }

                /* Also stop any running timers by overriding setTimeout temporarily */
                /* The theme.js IIFE timer was started before us; we can't clear it directly
                   but the CSS !important rules in canvas-renderer.php already handle visibility.
                   This clone replacement prevents future interactions. */
        }

        /* ═══════════════════════════════════════════════════════════════════
           INIT
           ═══════════════════════════════════════════════════════════════════ */
        function init() {
                injectCanvasStyles();
                initWidgets();

                /* Freeze hero slider in canvas mode (no auto-advance) */
                if (section === 'hero') {
                        freezeHeroSlider();
                }

                /* Capture phase so we intercept before any default handlers */
                document.addEventListener('mouseover',  onHoverIn,  true);
                document.addEventListener('mouseout',   onHoverOut, true);
                document.addEventListener('click',       onClick,     true);
                document.addEventListener('dblclick',    onDblClick,  true);
                document.addEventListener('focusout',    onBlur,      true);
                document.addEventListener('keydown',     onKeyDown,   true);
                window.addEventListener('message',      onParentMessage);
        }

        if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', init);
        } else {
                init();
        }
})();