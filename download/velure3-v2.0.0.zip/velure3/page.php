<?php
/**
 * Velure3 — Generic Page Template
 *
 * @package Velure3
 */

get_header();
?>

<div class="velure-section">
  <div class="velure-container" style="max-width:800px;">
    <?php while ( have_posts() ) : the_post(); ?>
      <article>
        <h1 style="font-size:clamp(2rem,4vw,3rem);margin-bottom:1.5rem;"><?php the_title(); ?></h1>
        <div style="line-height:1.8;color:#444;">
          <?php the_content(); ?>
        </div>
      </article>
    <?php endwhile; ?>
  </div>
</div>

<?php get_footer(); ?>