<?php
/**
 * Velure3 — Page d'Accueil (Classic PHP)
 * Reconstruit intégralement — v2.1.0
 *
 * Architecture : Classic PHP theme (pas FSE).
 * Données : ACF Options Page + WooCommerce + CPT, avec fallbacks statiques.
 * Sections : Hero Slider → Trust Bar → Catégories → Produits → Bannière Split
 *            → Témoignages → Marquee → Blog → Instagram
 *
 * @package Velure3
 * @version 2.1.0
 */

// ── Récupération des données (ACF ou fallbacks) ──
$hero_slides       = velure3_get_hero_slides();
$features          = velure3_get_features();
$categories        = velure3_get_product_categories( 10 );
$products_count    = (int) velure3_opt( 'featured_products_count', 8 );
$featured_products = velure3_get_featured_products( $products_count );
$split_banner      = velure3_get_split_banner();
$testimonials_count = (int) velure3_opt( 'testimonials_count', 3 );
$testimonials      = velure3_get_testimonials( $testimonials_count );
$brands            = velure3_get_brands();
$blog_count        = (int) velure3_opt( 'blog_posts_count', 3 );
$blog_posts        = velure3_get_blog_posts( $blog_count );
$instagram_items   = velure3_get_instagram_items();
$instagram_handle  = velure3_opt( 'instagram_handle', '@velure.paris' );

$section_titles = array(
	'categories'   => velure3_opt( 'section_title_categories', 'Explorer par Univers' ),
	'products'     => velure3_opt( 'section_title_products', 'Pièces Vedettes' ),
	'testimonials' => velure3_opt( 'section_title_testimonials', 'Ce Que Disent Nos Clients' ),
	'blog'         => velure3_opt( 'section_title_blog', 'Le Journal' ),
);

$star_svg = velure3_star_svg();

get_header();
?>


<!-- ═══════════════════════════════════════════════════════════════
     1. HERO — SLIDER PLEINE LARGEUR
     ═══════════════════════════════════════════════════════════════ -->
<section class="v-hero" aria-label="Bannière principale">

	<div class="v-hero-slider">
		<?php foreach ( $hero_slides as $i => $slide ) :
			$active = ( 0 === $i ) ? ' v-hero-slide--active' : '';
		?>
		<div class="v-hero-slide<?php echo $active; ?>" data-slide="<?php echo $i; ?>">
			<img
				src="<?php echo esc_url( $slide['image'] ); ?>"
				alt="<?php echo esc_attr( wp_strip_all_tags( $slide['title'] ) ); ?>"
				class="v-hero-slide-bg"
			/>
			<div class="v-hero-slide-overlay"></div>
			<div class="v-hero-slide-inner">
				<span class="v-hero-eyebrow"><?php echo esc_html( $slide['eyebrow'] ); ?></span>
				<h1 class="v-hero-title"><?php echo wp_kses_post( $slide['title'] ); ?></h1>
				<?php if ( ! empty( $slide['subtitle'] ) ) : ?>
				<p class="v-hero-subtitle"><?php echo esc_html( $slide['subtitle'] ); ?></p>
				<?php endif; ?>
				<a href="<?php echo esc_url( $slide['cta_link'] ); ?>" class="velure-btn velure-btn-primary">
					<?php echo esc_html( $slide['cta_text'] ); ?>
				</a>
			</div>
		</div>
		<?php endforeach; ?>

		<!-- Navigation dots -->
		<?php if ( count( $hero_slides ) > 1 ) : ?>
		<div class="v-hero-dots">
			<?php foreach ( $hero_slides as $i => $slide ) :
				$active = ( 0 === $i ) ? ' v-hero-dot--active' : '';
			?>
			<button class="v-hero-dot<?php echo $active; ?>" data-goto="<?php echo $i; ?>" aria-label="Slide <?php echo $i + 1; ?>"></button>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>

		<!-- Progress bar -->
		<div class="v-hero-progress"><div class="v-hero-progress-bar"></div></div>
	</div>

	<!-- Scroll indicator -->
	<div class="v-hero-scroll">
		<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polyline points="6 9 12 15 18 9"/></svg>
	</div>

</section>


<!-- ═══════════════════════════════════════════════════════════════
     2. BARRE DE CONFIANCE
     ═══════════════════════════════════════════════════════════════ -->
<section class="velure-section" style="padding:0;" aria-label="Engagements">
	<div class="velure-container">
		<div class="velure-features">
			<?php foreach ( $features as $feature ) : ?>
			<div class="velure-feature velure-animate">
				<div class="velure-feature-icon"><?php echo $feature['icon']; ?></div>
				<div class="velure-feature-text">
					<strong><?php echo esc_html( $feature['title'] ); ?></strong>
					<span><?php echo esc_html( $feature['desc'] ); ?></span>
				</div>
			</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>


<!-- ═══════════════════════════════════════════════════════════════
     3. CATÉGORIES — CARROUSEL HORIZONTAL
     ═══════════════════════════════════════════════════════════════ -->
<?php if ( ! empty( $categories ) ) : ?>
<section class="velure-section" aria-label="<?php echo esc_attr( $section_titles['categories'] ); ?>">
	<div class="velure-container">
		<h2 class="velure-section-heading"><?php echo esc_html( $section_titles['categories'] ); ?></h2>
		<div class="velure-carousel" id="velure-category-carousel">
			<div class="velure-carousel-track">
				<?php foreach ( $categories as $cat ) : ?>
				<a href="<?php echo esc_url( $cat['link'] ); ?>" class="velure-category-card velure-animate">
					<img src="<?php echo esc_url( $cat['image'] ); ?>" alt="<?php echo esc_attr( $cat['name'] ); ?>" loading="lazy" />
					<div class="velure-category-card-overlay">
						<span class="velure-category-card-label">Collection</span>
						<h3 class="velure-category-card-title"><?php echo esc_html( $cat['name'] ); ?></h3>
						<?php if ( $cat['count'] > 0 ) : ?>
						<span class="velure-category-card-count"><?php echo esc_html( $cat['count'] ); ?> pièces</span>
						<?php endif; ?>
					</div>
				</a>
				<?php endforeach; ?>
			</div>
			<button class="velure-carousel-arrow velure-carousel-arrow--prev" aria-label="Précédent">
				<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
			</button>
			<button class="velure-carousel-arrow velure-carousel-arrow--next" aria-label="Suivant">
				<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
			</button>
		</div>
	</div>
</section>
<?php endif; ?>


<!-- ═══════════════════════════════════════════════════════════════
     4. PRODUITS VEDETTES
     ═══════════════════════════════════════════════════════════════ -->
<?php if ( ! empty( $featured_products ) ) : ?>
<section class="velure-section velure-section-soft" aria-label="<?php echo esc_attr( $section_titles['products'] ); ?>">
	<div class="velure-container">
		<h2 class="velure-section-heading"><?php echo esc_html( $section_titles['products'] ); ?></h2>
		<div class="velure-grid velure-grid-4">
			<?php foreach ( $featured_products as $prod ) : ?>
			<div class="velure-product-card velure-animate">
				<div class="velure-product-card-image">
					<?php if ( $prod['image'] ) : ?>
					<img src="<?php echo esc_url( $prod['image'] ); ?>" alt="<?php echo esc_attr( $prod['name'] ); ?>" loading="lazy" />
					<?php else : ?>
					<div class="velure-skeleton" style="width:100%;height:100%;"></div>
					<?php endif; ?>
					<?php echo $prod['badge']; ?>
					<div class="velure-product-card-actions">
						<button class="velure-product-card-action" aria-label="Ajouter aux favoris">
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
						</button>
						<button class="velure-product-card-action" aria-label="Aperçu rapide">
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
						</button>
						<a href="<?php echo esc_url( $prod['link'] ); ?>" class="velure-product-card-action" aria-label="Voir le produit">
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
						</a>
					</div>
				</div>
				<div class="velure-product-card-info">
					<h3><?php echo esc_html( $prod['name'] ); ?></h3>
					<div class="velure-product-card-price"><?php echo $prod['price_html']; ?></div>
				</div>
			</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<?php endif; ?>


<!-- ═══════════════════════════════════════════════════════════════
     5. BANNIÈRE DOUBLE (SPLIT)
     ═══════════════════════════════════════════════════════════════ -->
<section class="velure-section" aria-label="Mise en avant">
	<div class="velure-container">
		<div class="velure-grid velure-grid-2" style="gap:1.5rem;">
			<?php foreach ( array( 'left', 'right' ) as $side ) :
				$banner = $split_banner[ $side ];
				$btn_class = 'velure-btn velure-btn-' . ( $banner['cta_style'] ?: 'primary' );
			?>
			<div class="v-split-card velure-animate">
				<img
					src="<?php echo esc_url( $banner['image'] ); ?>"
					alt="<?php echo esc_attr( $banner['title'] ); ?>"
					class="v-split-card-img"
					loading="lazy"
				/>
				<div class="v-split-card-content">
					<span class="velure-eyebrow" style="color:rgba(255,255,255,0.7);"><?php echo esc_html( $banner['eyebrow'] ); ?></span>
					<h2 class="v-split-card-title"><?php echo esc_html( $banner['title'] ); ?></h2>
					<p class="v-split-card-desc"><?php echo esc_html( $banner['desc'] ); ?></p>
					<a href="<?php echo esc_url( $banner['cta_link'] ); ?>" class="<?php echo esc_attr( $btn_class ); ?>">
						<?php echo esc_html( $banner['cta_text'] ); ?>
					</a>
				</div>
			</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>


<!-- ═══════════════════════════════════════════════════════════════
     6. TÉMOIGNAGES
     ═══════════════════════════════════════════════════════════════ -->
<?php if ( ! empty( $testimonials ) ) : ?>
<section class="velure-section velure-section-soft" aria-label="<?php echo esc_attr( $section_titles['testimonials'] ); ?>">
	<div class="velure-container">
		<h2 class="velure-section-heading"><?php echo esc_html( $section_titles['testimonials'] ); ?></h2>
		<div class="velure-grid velure-grid-3">
			<?php foreach ( $testimonials as $t ) : ?>
			<div class="velure-testimonial velure-animate">
				<div class="velure-testimonial-stars">
					<?php for ( $s = 0; $s < $t['stars']; $s++ ) echo $star_svg; ?>
				</div>
				<p class="velure-testimonial-text">&laquo; <?php echo esc_html( $t['text'] ); ?> &raquo;</p>
				<p class="velure-testimonial-author"><?php echo esc_html( $t['author'] ); ?></p>
				<?php if ( ! empty( $t['role'] ) ) : ?>
				<p class="velure-testimonial-role"><?php echo esc_html( $t['role'] ); ?></p>
				<?php endif; ?>
			</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<?php endif; ?>


<!-- ═══════════════════════════════════════════════════════════════
     7. MARQUEE — MARQUES
     ═══════════════════════════════════════════════════════════════ -->
<?php if ( ! empty( $brands ) ) : ?>
<section class="velure-section velure-section-dark" style="padding:0;" aria-label="Marques partenaires">
	<div class="velure-marquee">
		<div class="velure-marquee-track">
			<?php foreach ( $brands as $brand ) : ?>
			<span class="velure-marquee-item"><?php echo esc_html( $brand ); ?></span>
			<?php endforeach; ?>
			<?php foreach ( $brands as $brand ) : ?>
			<span class="velure-marquee-item"><?php echo esc_html( $brand ); ?></span>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<?php endif; ?>


<!-- ═══════════════════════════════════════════════════════════════
     8. BLOG / JOURNAL
     ═══════════════════════════════════════════════════════════════ -->
<?php if ( ! empty( $blog_posts ) ) : ?>
<section class="velure-section" aria-label="<?php echo esc_attr( $section_titles['blog'] ); ?>">
	<div class="velure-container">
		<h2 class="velure-section-heading"><?php echo esc_html( $section_titles['blog'] ); ?></h2>
		<div class="velure-grid velure-grid-3">
			<?php foreach ( $blog_posts as $post ) : ?>
			<article class="velure-blog-card velure-animate">
				<div class="velure-blog-card-image">
					<?php if ( ! empty( $post['image'] ) ) : ?>
					<img src="<?php echo esc_url( $post['image'] ); ?>" alt="<?php echo esc_attr( $post['title'] ); ?>" loading="lazy" />
					<?php else : ?>
					<div style="background:var(--v-color-soft);width:100%;aspect-ratio:4/3;display:flex;align-items:center;justify-content:center;">
						<span style="color:#999;font-size:0.85rem;">Pas d'image</span>
					</div>
					<?php endif; ?>
				</div>
				<div class="velure-blog-card-meta">
					<time datetime="<?php echo esc_attr( $post['date'] ); ?>"><?php echo esc_html( $post['date'] ); ?></time>
					<?php if ( ! empty( $post['category'] ) ) : ?>
					<span style="margin:0 6px;opacity:0.4;">&bull;</span>
					<span><?php echo esc_html( $post['category'] ); ?></span>
					<?php endif; ?>
				</div>
				<h3 class="velure-blog-card-title"><?php echo esc_html( $post['title'] ); ?></h3>
				<p class="velure-blog-card-excerpt"><?php echo esc_html( $post['excerpt'] ); ?></p>
			</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<?php endif; ?>


<!-- ═══════════════════════════════════════════════════════════════
     9. INSTAGRAM FEED
     ═══════════════════════════════════════════════════════════════ -->
<?php if ( ! empty( $instagram_items ) ) : ?>
<section class="velure-section velure-section-soft" aria-label="Instagram">
	<div class="velure-container">
		<h2 class="velure-section-heading"><?php echo esc_html( $instagram_handle ); ?></h2>
		<div class="velure-instagram-grid">
			<?php foreach ( $instagram_items as $item ) : ?>
			<a href="<?php echo esc_url( $item['link'] ); ?>" class="velure-instagram-item" target="_blank" rel="noopener">
				<img src="<?php echo esc_url( $item['image'] ); ?>" alt="Instagram — Velure" loading="lazy" />
			</a>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<?php endif; ?>


<?php
get_footer();